import React from 'react';
import logo from './logo.svg';
import './App.css';
import AppHeader from './components/AppHeader'
import PhotoGallery from './components/PhotoGallery'
import RandomHeader from './components/RandomHeader'

class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {
      dogType: "husky",
      dogFocus:"placeholder",
      logo:logo
  };
  this.setDogType = this.setDogType.bind(this);
  this.setDogFocus = this.setDogFocus.bind(this);
}
 render(){
  return (
    <div className="App">
      <AppHeader dogBreed={this.state.dogType} selectedType={this.setDogType}/>
      <RandomHeader dogBreed={this.state.dogType} dogFocus ={this.state.dogFocus}/>
      <PhotoGallery dogBreed={this.state.dogType} selectedFocus={this.setDogFocus}/>

    </div>
    
  );
}


setDogType(type){
  this.setState({
      dogType: type
  });
}

setDogFocus(focus){
  this.setState({
      dogFocus: focus
  });
}
}

export default App;
