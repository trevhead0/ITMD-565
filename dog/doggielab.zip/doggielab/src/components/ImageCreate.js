import React from 'react'

function ImageCreate(props) {
    return (
        <React.Fragment>
            <img src={props.url} alt="Doggo" />
        </React.Fragment>
    )
}

export default ImageCreate