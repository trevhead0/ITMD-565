import React from 'react'

function BreedSelect(props) {
    return (
        <React.Fragment>
            <select id="dropdown" onChange={(e) => {
                props.selectedType(e.target.value);
                props.selectedTitle(e.target.options[e.target.selectedIndex].text);
            }}>
                <option value="husky">Husky</option>
                <option value="boxer">Boxer</option>
                <option value="pomeranian">Pomeranian</option>
            </select>
        </React.Fragment>
    )
}

export default BreedSelect