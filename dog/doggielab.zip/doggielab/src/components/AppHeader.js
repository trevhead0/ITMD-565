import React from 'react';
import BreedSelect from './BreedSelect'
class AppHeader extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dogTitle: "Husky"
        };
        this.setTitle = this.setTitle.bind(this);
    }
    render() {
        return (<div className="myJumbo">
            <h1 className="display-4">{this.state.dogTitle} Dog Gallery</h1>
            <p className="lead">ITMD 565 - tloveday@hawk.iit.edu</p>
            <BreedSelect selectedType={this.props.selectedType} selectedTitle={this.setTitle} />
        </div>);


    }
    setTitle(title) {
        this.setState({
            dogTitle: title
        });
    }

}

export default AppHeader;