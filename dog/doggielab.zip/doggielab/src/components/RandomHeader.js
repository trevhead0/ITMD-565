import React from 'react';
import ImageCreate from './ImageCreate';

class RandomHeader extends React.Component {
    constructor(props) {
        super(props);
        //I could move state out of the random header, 
        //but i feel that would be more code and less organized.
        this.state = {
            photos: "",
        }
    }

    componentDidMount() {
        //On first load, grab a random picture of a random breed.
        this.getRandomFirstPhoto();
    }
    componentDidUpdate(prevProps) {

        // If the user changes dog breed, grab a random breed picture from selected
        if (this.props.dogBreed !== prevProps.dogBreed) {
            this.getRandomPhoto();
        }
        // If focus has changed to another picture, switch to that picture
        if (this.props.dogFocus !== prevProps.dogFocus) {
            this.getDogFocus();
        }
    }


    render() {

        return (<div className="myJumbo">
            <ul className="random">
                <li key={this.state.photo}>
                    <ImageCreate url={this.state.photo} />

                </li>
            </ul>
        </div>);


    }

    getDogFocus() {
        //sets photo to the url of the focused picture
        this.setState({ photo: this.props.dogFocus });
    }

    getRandomPhoto() {

        fetch("https://dog.ceo/api/breed/" + this.props.dogBreed + "/images/random")
            .then(response => response.json())
            .then(result => {
                //console.log(result);
                console.log("here we go again");
                var a = result.message;

                //a = a.replace(/"|{|}/gi, "");
                //a.split("[")
                console.log(a);

                this.setState({ photo: a });

            }

            )
            .catch(error => console.log('error', error));

    }
    getRandomFirstPhoto() {

        fetch("https://dog.ceo/api/breeds/image/random")
            .then(response => response.json())
            .then(result => {
                //console.log(result);
                console.log("here we go again");
                var a = result.message;

                //a = a.replace(/"|{|}/gi, "");
                //a.split("[")
                console.log(a);

                this.setState({ photo: a });

            }

            )
            .catch(error => console.log('error', error));

    }
}



export default RandomHeader;