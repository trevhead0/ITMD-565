import React from 'react';
import ImageCreate from './ImageCreate';

class PhotoGallery extends React.Component {
    constructor(props) {
        super(props);
        //I could move state out of the random header, 
        //but i feel that would be more code and less organized.
        this.state = {
            photos: []
        }
    }

    componentDidMount() {
        this.getPhotos();
    }

    componentDidUpdate(prevProps) {

        // Typical usage (don't forget to compare props):
        if (this.props.dogBreed !== prevProps.dogBreed) {
            this.getPhotos();
        }
    }

    render() {
        return (<div className="myJumbo">
            <ul className="flexy">
                {this.state.photos.map(photourl => {
                    return (
                        <li key={photourl}
                            onClick={(e) => { this.props.selectedFocus(e.target.src) }}
                        >
                            <ImageCreate url={photourl} />
                        </li>
                    )
                })}
            </ul>


        </div>);

    }

    getPhotos() {
        //This url can be changed out to give different number of pictures.
        //I chose 20 so it didnt load all the pictures for that breed.  If needed, removing 20 will work
        fetch("https://dog.ceo/api/breed/" + this.props.dogBreed + "/images/random/20")
            .then(response => response.json())
            .then(result => {
                //console.log(result);
                console.log("here we go again");
                var a = result.message;

                //a = a.replace(/"|{|}/gi, "");
                //a.split("[")
                console.log(a);

                this.setState({ photos: a });

            }

            )
            .catch(error => console.log('error', error));

    }
}


export default PhotoGallery;